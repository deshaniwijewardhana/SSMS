USE [SuperstoreDW];
GO

INSERT INTO [dbo].[DimCustomer] (CustomerID, CustomerName, Segment)
VALUES
('CG-12520', 'Claire Gute', 'Consumer'),
('DV-13045', 'Darrin Van Huff', 'Corporate'),
('SO-20335', 'Sean O''Donnell', 'Consumer'),
('BH-11710', 'Brosina Hoffman', 'Consumer'),
('AA-10480', 'Andrew Allen', 'Consumer'),
('IM-15070', 'Irene Maddox', 'Consumer'),
('HP-14815', 'Harold Pawlan', 'Home Office'),
('PK-19075', 'Pete Kriz', 'Consumer'),
('AG-10270', 'Alejandro Grove', 'Consumer'),
('ZD-21925', 'Zuschuss Donatelli', 'Consumer');
GO
