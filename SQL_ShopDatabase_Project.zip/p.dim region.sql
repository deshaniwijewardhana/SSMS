INSERT INTO [dbo].[DimRegion] (Region, Country)
VALUES 
    ('South', 'United States'),
    ('West', 'United States'),
    ('Central', 'United States'),
    ('East', 'United States'),
    ('South', 'Canada'),
    ('West', 'Canada'),
    ('Central', 'Canada'),
    ('East', 'Canada'),
    ('South', 'Mexico'),
    ('West', 'Mexico');
GO