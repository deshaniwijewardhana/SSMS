IF OBJECT_ID('dbo.Staging_Superstore_Cleaned', 'U') IS NOT NULL
    DROP TABLE dbo.Staging_Superstore_Cleaned;