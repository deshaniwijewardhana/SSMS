SELECT TOP (50) [RegionKey]
      ,[Region]
      ,[Country]
  FROM [SuperstoreDW].[dbo].[DimRegion]
