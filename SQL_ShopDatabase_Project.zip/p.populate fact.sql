INSERT INTO FactSales (
    OrderID, CustomerKey, ProductKey, RegionKey,
    OrderDate, ShipDate, ShipMode, Quantity, Sales, Discount, Profit,
    City, State, PostalCode, Country
)
SELECT
    s.OrderID,
    c.CustomerKey,
    p.ProductKey,
    r.RegionKey,
    s.OrderDate,
    s.ShipDate,
    s.ShipMode,
    s.Quantity,
    s.Sales,
    s.Discount,
    s.Profit,
    s.City,
    s.State,
    s.PostalCode,
    s.Country
FROM Staging_Superstore s
JOIN DimCustomer c ON s.CustomerID = c.CustomerID
JOIN DimProduct p ON s.ProductID = p.ProductID
JOIN DimRegion r ON s.Region = r.Region;
