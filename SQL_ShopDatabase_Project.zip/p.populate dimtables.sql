-- DimCustomer (distinct customers)
INSERT INTO DimCustomer (CustomerID, CustomerName, Segment)
SELECT DISTINCT 
    CustomerID, 
    CustomerName, 
    Segment
FROM Staging_Superstore
WHERE CustomerID IS NOT NULL;


-- DimProduct (distinct products)
INSERT INTO DimProduct (ProductID, ProductName, Category, SubCategory)
SELECT DISTINCT 
    ProductID, 
    ProductName, 
    Category, 
    SubCategory
FROM Staging_Superstore
WHERE ProductID IS NOT NULL;

-- DimRegion (distinct regions)
INSERT INTO DimRegion (Region)
SELECT DISTINCT 
    Region
FROM Staging_Superstore
WHERE Region IS NOT NULL;
