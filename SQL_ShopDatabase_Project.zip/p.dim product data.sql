INSERT INTO [dbo].[DimProduct] (ProductID, ProductName, Category, SubCategory)
VALUES
('FUR-BO-10001798', 'Bush Somerset Collection Bookcase', 'Furniture', 'Bookcases'),
('FUR-CH-10000454', 'Hon Deluxe Fabric Upholstered Stacking Chairs, Rounded Back', 'Furniture', 'Chairs'),
('OFF-LA-10000240', 'Self-Adhesive Address Labels for Typewriters by Universal', 'Office Supplies', 'Labels'),
('FUR-TA-10000577', 'Bretford CR4500 Series Slim Rectangular Table', 'Furniture', 'Tables'),
('OFF-ST-10000760', 'Eldon Fold ''N Roll Cart System', 'Office Supplies', 'Storage'),
('FUR-FU-10001487', 'Eldon Expressions Wood and Plastic Desk Accessories, Cherry Wood', 'Furniture', 'Furnishings'),
('OFF-AR-10002833', 'Newell 322', 'Office Supplies', 'Art'),
('TEC-PH-10002275', 'Mitel 5320 IP Phone VoIP phone', 'Technology', 'Phones'),
('OFF-BI-10003910', 'DXL Angle-View Binders with Locking Rings by Samsill', 'Office Supplies', 'Binders'),
('OFF-AP-10002892', 'Belkin F5C206VTEL 6 Outlet Surge', 'Office Supplies', 'Appliances');
GO

