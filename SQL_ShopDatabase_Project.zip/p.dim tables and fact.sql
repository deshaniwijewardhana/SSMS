-- 1. Create dimension tables first
CREATE TABLE DimCustomer (
    CustomerKey INT IDENTITY(1,1) PRIMARY KEY,
    CustomerID VARCHAR(20) NOT NULL,
    CustomerName VARCHAR(100) NOT NULL,
    Segment VARCHAR(50) NOT NULL
);

CREATE TABLE DimProduct (
    ProductKey INT IDENTITY(1,1) PRIMARY KEY,
    ProductID VARCHAR(20) NOT NULL,
    ProductName VARCHAR(100) NOT NULL,
    Category VARCHAR(50),
    SubCategory VARCHAR(50)
);

CREATE TABLE DimRegion (
    RegionKey INT IDENTITY(1,1) PRIMARY KEY,
    Region VARCHAR(50) NOT NULL
);

-- 2. Then create FactSales
CREATE TABLE FactSales (
    SalesKey INT IDENTITY(1,1) PRIMARY KEY,
    OrderID VARCHAR(20) NULL,
    CustomerKey INT NOT NULL FOREIGN KEY REFERENCES DimCustomer(CustomerKey),
    ProductKey INT NOT NULL FOREIGN KEY REFERENCES DimProduct(ProductKey),
    RegionKey INT NOT NULL FOREIGN KEY REFERENCES DimRegion(RegionKey),
    ShipMode VARCHAR(20) NOT NULL,
    Quantity INT NOT NULL,
    Sales DECIMAL(10,2) NOT NULL,
    Discount DECIMAL(5,2) NOT NULL,
    Profit DECIMAL(10,2) NOT NULL,
    City VARCHAR(50) NOT NULL,
    State VARCHAR(50) NOT NULL,
    PostalCode VARCHAR(10) NOT NULL,
    Region VARCHAR(50) NOT NULL,
    Country VARCHAR(50) NOT NULL
);
